#ifndef _ETHERCAT_H_
#define _ETHERCAT_H_
#include "ecrt.h"
#include <stdio.h>

// #define FREQUENCY 1000
// #define PRIORITY 1
// #define MAX_VELOCITY_1 900000
// #define MAX_VELOCITY_2 160000
// #define MAX_VELOCITY_3 112000
// #define PERIODS_PER_SECOND   1000
// #define INIT_TIME 2
// #define ERROR 0.1
// #define RUNNING_TIME 150/*seconds*/




// void check_domain_state(uint16_t slave_position);
// void check_master_state(void);
// void check_slave_config_states(int slave_position);
// int config();

#endif