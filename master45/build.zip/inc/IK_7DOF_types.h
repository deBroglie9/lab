/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * IK_7DOF_types.h
 *
 * Code generation for function 'IK_7DOF'
 *
 */

#ifndef IK_7DOF_TYPES_H
#define IK_7DOF_TYPES_H

/* Include files */
#include "rtwtypes.h"

#endif
/* End of code generation (IK_7DOF_types.h) */
