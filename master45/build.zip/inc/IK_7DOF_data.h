/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * IK_7DOF_data.h
 *
 * Code generation for function 'IK_7DOF_data'
 *
 */

#ifndef IK_7DOF_DATA_H
#define IK_7DOF_DATA_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

/* Variable Declarations */
extern boolean_T isInitialized_IK_7DOF;

#endif
/* End of code generation (IK_7DOF_data.h) */
