/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * IK_7DOF_data.c
 *
 * Code generation for function 'IK_7DOF_data'
 *
 */

/* Include files */
#include "IK_7DOF_data.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
boolean_T isInitialized_IK_7DOF = false;

/* End of code generation (IK_7DOF_data.c) */
