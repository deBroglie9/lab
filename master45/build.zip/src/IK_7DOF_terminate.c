/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * IK_7DOF_terminate.c
 *
 * Code generation for function 'IK_7DOF_terminate'
 *
 */

/* Include files */
#include "IK_7DOF_terminate.h"
#include "IK_7DOF_data.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void IK_7DOF_terminate(void)
{
  isInitialized_IK_7DOF = false;
}

/* End of code generation (IK_7DOF_terminate.c) */
